-- ============================================================
--  Smart Study Planner — Database Schema
--  Import: mysql -u root -p < database/schema.sql
--  Or paste into phpMyAdmin SQL tab
-- ============================================================

CREATE DATABASE IF NOT EXISTS smart_study_planner
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE smart_study_planner;

-- ----------------------------------------------------------------
-- users
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100)  NOT NULL,
    email         VARCHAR(150)  NOT NULL UNIQUE,
    password_hash VARCHAR(255)  NOT NULL,
    created_at    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------
-- subjects
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS subjects (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    name        VARCHAR(100) NOT NULL,
    color       VARCHAR(7)   NOT NULL DEFAULT '#4f46e5',
    description TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------
-- tasks
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tasks (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    subject_id  INT UNSIGNED DEFAULT NULL,
    title       VARCHAR(200) NOT NULL,
    description TEXT,
    due_date    DATE         DEFAULT NULL,
    priority    ENUM('low','medium','high')                    NOT NULL DEFAULT 'medium',
    status      ENUM('pending','in_progress','completed')      NOT NULL DEFAULT 'pending',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL,
    INDEX idx_user     (user_id),
    INDEX idx_status   (status),
    INDEX idx_due_date (due_date)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------
-- schedule
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS schedule (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    subject_id  INT UNSIGNED DEFAULT NULL,
    title       VARCHAR(200) NOT NULL,
    day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
    start_time  TIME NOT NULL,
    end_time    TIME NOT NULL,
    notes       TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_day  (day_of_week)
) ENGINE=InnoDB;
