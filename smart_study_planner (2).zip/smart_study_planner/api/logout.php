<?php
session_name('ssp_session');
session_start();
$_SESSION = [];
session_destroy();
header('Location: ../login.html');
exit;
