<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();
$userId = currentUserId();

$allowedDays = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];

switch ($_SERVER['REQUEST_METHOD']) {

    case 'GET':
        $stmt = $pdo->prepare(
            'SELECT sc.*, s.name AS subject_name, s.color AS subject_color
             FROM schedule sc LEFT JOIN subjects s ON sc.subject_id = s.id
             WHERE sc.user_id = ?
             ORDER BY FIELD(sc.day_of_week,"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"),
                      sc.start_time ASC'
        );
        $stmt->execute([$userId]);
        jsonResponse(true, '', $stmt->fetchAll());
        break;

    case 'POST':
        $input     = getJsonInput();
        $title     = trim($input['title']       ?? '');
        $day       =      $input['day_of_week'] ?? '';
        $start     =      $input['start_time']  ?? '';
        $end       =      $input['end_time']    ?? '';
        $notes     = trim($input['notes']       ?? '');
        $subjectId = !empty($input['subject_id']) ? (int)$input['subject_id'] : null;

        if (!$title || !$day || !$start || !$end) {
            jsonResponse(false, 'Title, day, start time and end time are required.');
        }
        if (!in_array($day, $allowedDays)) {
            jsonResponse(false, 'Invalid day of week.');
        }
        if ($start >= $end) {
            jsonResponse(false, 'End time must be after start time.');
        }

        $stmt = $pdo->prepare(
            'INSERT INTO schedule (user_id, subject_id, title, day_of_week, start_time, end_time, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$userId, $subjectId, $title, $day, $start, $end, $notes]);

        jsonResponse(true, 'Session added to schedule.', ['id' => (int) $pdo->lastInsertId()]);
        break;

    case 'DELETE':
        $id = (int) ($_GET['id'] ?? 0);
        if (!$id) jsonResponse(false, 'Schedule ID required.');

        $stmt = $pdo->prepare('DELETE FROM schedule WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $userId]);

        if ($stmt->rowCount() === 0) jsonResponse(false, 'Entry not found.');
        jsonResponse(true, 'Schedule entry deleted.');
        break;

    default:
        jsonResponse(false, 'Method not allowed.', null, 405);
}
