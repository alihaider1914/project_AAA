<?php
session_name('ssp_session');
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed.', null, 405);
}

$input    = getJsonInput();
$name     = trim($input['name']     ?? '');
$email    = trim($input['email']    ?? '');
$password =      $input['password'] ?? '';

if (!$name || !$email || !$password) {
    jsonResponse(false, 'All fields are required.');
}
if (!validateEmail($email)) {
    jsonResponse(false, 'Enter a valid email address.');
}
if (strlen($password) < 6) {
    jsonResponse(false, 'Password must be at least 6 characters.');
}
if (strlen($name) < 2) {
    jsonResponse(false, 'Name must be at least 2 characters.');
}

$stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
$stmt->execute([$email]);
if ($stmt->fetch()) {
    jsonResponse(false, 'This email is already registered.');
}

$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
$stmt = $pdo->prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)');
$stmt->execute([$name, $email, $hash]);

jsonResponse(true, 'Account created! You can now log in.');
