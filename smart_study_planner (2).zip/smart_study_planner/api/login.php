<?php
session_name('ssp_session');
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed.', null, 405);
}

$input    = getJsonInput();
$email    = trim($input['email']    ?? '');
$password =      $input['password'] ?? '';

if (!$email || !$password) {
    jsonResponse(false, 'Email and password are required.');
}

$stmt = $pdo->prepare('SELECT id, name, email, password_hash FROM users WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    jsonResponse(false, 'Incorrect email or password.');
}

session_regenerate_id(true);
$_SESSION['user_id']    = $user['id'];
$_SESSION['user_name']  = $user['name'];
$_SESSION['user_email'] = $user['email'];

jsonResponse(true, 'Login successful.', [
    'name'  => $user['name'],
    'email' => $user['email'],
]);
