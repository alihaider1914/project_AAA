<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();
$userId = currentUserId();

switch ($_SERVER['REQUEST_METHOD']) {

    case 'GET':
        $stmt = $pdo->prepare('SELECT id, name, email, created_at FROM users WHERE id = ?');
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        $stats = $pdo->prepare('
            SELECT
                (SELECT COUNT(*) FROM subjects WHERE user_id = :u1) AS total_subjects,
                (SELECT COUNT(*) FROM tasks    WHERE user_id = :u2) AS total_tasks,
                (SELECT COUNT(*) FROM tasks    WHERE user_id = :u3 AND status = "completed") AS completed_tasks,
                (SELECT COUNT(*) FROM schedule WHERE user_id = :u4) AS schedule_entries
        ');
        $stats->execute([':u1' => $userId, ':u2' => $userId, ':u3' => $userId, ':u4' => $userId]);

        jsonResponse(true, '', array_merge($user, $stats->fetch()));
        break;

    case 'PUT':
        $input    = getJsonInput();
        $name     = trim($input['name'] ?? '');
        $password = $input['new_password'] ?? '';

        if (!$name) jsonResponse(false, 'Name is required.');
        if (strlen($name) < 2) jsonResponse(false, 'Name must be at least 2 characters.');

        if ($password !== '') {
            if (strlen($password) < 6) jsonResponse(false, 'New password must be at least 6 characters.');
            $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
            $stmt = $pdo->prepare('UPDATE users SET name = ?, password_hash = ? WHERE id = ?');
            $stmt->execute([$name, $hash, $userId]);
        } else {
            $stmt = $pdo->prepare('UPDATE users SET name = ? WHERE id = ?');
            $stmt->execute([$name, $userId]);
        }

        $_SESSION['user_name'] = $name;
        jsonResponse(true, 'Profile updated successfully.');
        break;

    default:
        jsonResponse(false, 'Method not allowed.', null, 405);
}
