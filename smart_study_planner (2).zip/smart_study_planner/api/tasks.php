<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();
$userId = currentUserId();

$allowedPriorities = ['low', 'medium', 'high'];
$allowedStatuses   = ['pending', 'in_progress', 'completed'];

switch ($_SERVER['REQUEST_METHOD']) {

    case 'GET':
        $status = $_GET['status'] ?? null;
        if ($status && in_array($status, $allowedStatuses)) {
            $stmt = $pdo->prepare(
                'SELECT t.*, s.name AS subject_name, s.color AS subject_color
                 FROM tasks t LEFT JOIN subjects s ON t.subject_id = s.id
                 WHERE t.user_id = ? AND t.status = ?
                 ORDER BY t.due_date ASC, FIELD(t.priority,"high","medium","low")'
            );
            $stmt->execute([$userId, $status]);
        } else {
            $stmt = $pdo->prepare(
                'SELECT t.*, s.name AS subject_name, s.color AS subject_color
                 FROM tasks t LEFT JOIN subjects s ON t.subject_id = s.id
                 WHERE t.user_id = ?
                 ORDER BY t.due_date ASC, FIELD(t.priority,"high","medium","low")'
            );
            $stmt->execute([$userId]);
        }
        jsonResponse(true, '', $stmt->fetchAll());
        break;

    case 'POST':
        $input     = getJsonInput();
        $title     = trim($input['title']       ?? '');
        $desc      = trim($input['description'] ?? '');
        $dueDate   =      $input['due_date']    ?? null;
        $priority  =      $input['priority']    ?? 'medium';
        $subjectId = !empty($input['subject_id']) ? (int)$input['subject_id'] : null;

        if (!$title) jsonResponse(false, 'Task title is required.');
        if (!in_array($priority, $allowedPriorities)) $priority = 'medium';
        if ($dueDate && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dueDate)) $dueDate = null;

        $stmt = $pdo->prepare(
            'INSERT INTO tasks (user_id, subject_id, title, description, due_date, priority)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$userId, $subjectId, $title, $desc, $dueDate, $priority]);

        jsonResponse(true, 'Task added successfully.', ['id' => (int) $pdo->lastInsertId()]);
        break;

    case 'PATCH':
        $input  = getJsonInput();
        $id     = (int) ($_GET['id'] ?? 0);
        $status = $input['status'] ?? null;

        if (!$id) jsonResponse(false, 'Task ID required.');
        if (!$status || !in_array($status, $allowedStatuses)) jsonResponse(false, 'Invalid status value.');

        $stmt = $pdo->prepare('UPDATE tasks SET status = ? WHERE id = ? AND user_id = ?');
        $stmt->execute([$status, $id, $userId]);

        if ($stmt->rowCount() === 0) jsonResponse(false, 'Task not found.');
        jsonResponse(true, 'Task status updated.');
        break;

    case 'DELETE':
        $id = (int) ($_GET['id'] ?? 0);
        if (!$id) jsonResponse(false, 'Task ID required.');

        $stmt = $pdo->prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $userId]);

        if ($stmt->rowCount() === 0) jsonResponse(false, 'Task not found.');
        jsonResponse(true, 'Task deleted.');
        break;

    default:
        jsonResponse(false, 'Method not allowed.', null, 405);
}
