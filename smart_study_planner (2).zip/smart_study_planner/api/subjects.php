<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();
$userId = currentUserId();

switch ($_SERVER['REQUEST_METHOD']) {

    case 'GET':
        $stmt = $pdo->prepare(
            'SELECT s.*,
                    (SELECT COUNT(*) FROM tasks t WHERE t.subject_id = s.id) AS task_count
             FROM subjects s
             WHERE s.user_id = ?
             ORDER BY s.created_at DESC'
        );
        $stmt->execute([$userId]);
        jsonResponse(true, '', $stmt->fetchAll());
        break;

    case 'POST':
        $input = getJsonInput();
        $name  = trim($input['name']        ?? '');
        $color = trim($input['color']       ?? '#4f46e5');
        $desc  = trim($input['description'] ?? '');

        if (!$name) jsonResponse(false, 'Subject name is required.');
        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) $color = '#4f46e5';

        $stmt = $pdo->prepare('INSERT INTO subjects (user_id, name, color, description) VALUES (?, ?, ?, ?)');
        $stmt->execute([$userId, $name, $color, $desc]);

        jsonResponse(true, 'Subject added successfully.', ['id' => (int) $pdo->lastInsertId()]);
        break;

    case 'DELETE':
        $id = (int) ($_GET['id'] ?? 0);
        if (!$id) jsonResponse(false, 'Subject ID required.');

        $stmt = $pdo->prepare('DELETE FROM subjects WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $userId]);

        if ($stmt->rowCount() === 0) jsonResponse(false, 'Subject not found.');
        jsonResponse(true, 'Subject deleted.');
        break;

    default:
        jsonResponse(false, 'Method not allowed.', null, 405);
}
