/* ============================================================
   Smart Study Planner — Shared JavaScript Utilities
   ============================================================ */

// ---------- Toast Notifications ----------

function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const id   = `toast_${Date.now()}`;
  const icons = {
    success: 'bi-check-circle-fill',
    danger:  'bi-x-circle-fill',
    warning: 'bi-exclamation-triangle-fill',
    info:    'bi-info-circle-fill',
  };
  const icon = icons[type] || icons.info;

  container.insertAdjacentHTML('beforeend', `
    <div id="${id}" class="toast align-items-center text-bg-${type} border-0 show mb-2" role="alert" aria-live="assertive">
      <div class="d-flex">
        <div class="toast-body d-flex align-items-center gap-2 fw-500">
          <i class="bi ${icon}"></i> ${message}
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" onclick="this.closest('.toast').remove()"></button>
      </div>
    </div>
  `);

  setTimeout(() => document.getElementById(id)?.remove(), 4500);
}

// ---------- API Helper ----------

async function api(url, method = 'GET', body = null) {
  const options = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) options.body = JSON.stringify(body);
  try {
    const res = await fetch(url, options);
    return await res.json();
  } catch {
    return { success: false, message: 'Network error. Is the server running?' };
  }
}

// ---------- Button Loading State ----------

function setLoading(btn, loading) {
  if (loading) {
    btn.dataset.html = btn.innerHTML;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status"></span>Please wait…';
    btn.disabled = true;
  } else {
    btn.innerHTML = btn.dataset.html || btn.innerHTML;
    btn.disabled = false;
  }
}

// ---------- Formatting Helpers ----------

function formatDate(str) {
  if (!str) return '—';
  const [y, m, d] = str.split('-');
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${months[parseInt(m,10)-1]} ${parseInt(d,10)}, ${y}`;
}

function formatTime(t) {
  if (!t) return '';
  const [h, m] = t.split(':');
  const hr = parseInt(h, 10);
  const ampm = hr >= 12 ? 'PM' : 'AM';
  const h12 = hr % 12 || 12;
  return `${h12}:${m} ${ampm}`;
}

function isDueSoon(dateStr) {
  if (!dateStr) return false;
  const today = new Date(); today.setHours(0,0,0,0);
  const due   = new Date(dateStr + 'T00:00:00');
  const diff  = Math.ceil((due - today) / 86400000);
  return diff >= 0 && diff <= 3;
}

function isPastDue(dateStr) {
  if (!dateStr) return false;
  const today = new Date(); today.setHours(0,0,0,0);
  const due   = new Date(dateStr + 'T00:00:00');
  return due < today;
}

// ---------- Badge Renderers ----------

function priorityBadge(p) {
  return `<span class="badge-priority-${p}">${p.charAt(0).toUpperCase()+p.slice(1)}</span>`;
}

function statusBadge(s) {
  const labels = { pending: 'Pending', in_progress: 'In Progress', completed: 'Completed' };
  return `<span class="badge-status-${s}">${labels[s] || s}</span>`;
}

function subjectPill(name, color) {
  if (!name) return '';
  return `<span class="subject-dot" style="color:${color || '#4f46e5'}">${name}</span>`;
}

// ---------- Confirm Delete Dialog ----------

function confirmDelete(message = 'Are you sure you want to delete this?') {
  return window.confirm(message);
}
