<?php
// Expects $pageTitle (string) and $activePage (string) to be set before including
if (session_status() === PHP_SESSION_NONE) {
    session_name('ssp_session');
    session_start();
}
require_once __DIR__ . '/auth.php';
requireLogin();
$currentUser  = htmlspecialchars($_SESSION['user_name']  ?? 'User', ENT_QUOTES, 'UTF-8');
$currentEmail = htmlspecialchars($_SESSION['user_email'] ?? '',      ENT_QUOTES, 'UTF-8');
$avatarLetter = strtoupper(substr($_SESSION['user_name'] ?? 'U', 0, 1));
$title        = htmlspecialchars($pageTitle ?? 'Dashboard', ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $title ?> | StudyPlanner</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

<!-- ===== SIDEBAR ===== -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="d-flex align-items-center gap-2">
      <div class="brand-icon"><i class="bi bi-mortarboard-fill"></i></div>
      <div>
        <h5 class="mb-0 text-white fw-800">Study<span class="text-indigo-300">Planner</span></h5>
        <small class="text-white-50" style="font-size:.7rem">Smart Learning System</small>
      </div>
    </div>
  </div>

  <nav class="sidebar-nav mt-2">
    <p class="nav-section-label">Main</p>

    <div class="nav-item">
      <a href="dashboard.php" class="nav-link <?= ($activePage ?? '') === 'dashboard' ? 'active' : '' ?>">
        <i class="bi bi-grid-1x2-fill"></i><span>Dashboard</span>
      </a>
    </div>
    <div class="nav-item">
      <a href="addsubject.php" class="nav-link <?= ($activePage ?? '') === 'subjects' ? 'active' : '' ?>">
        <i class="bi bi-journal-bookmark-fill"></i><span>Subjects</span>
      </a>
    </div>
    <div class="nav-item">
      <a href="addtask.php" class="nav-link <?= ($activePage ?? '') === 'tasks' ? 'active' : '' ?>">
        <i class="bi bi-check2-square"></i><span>Tasks</span>
      </a>
    </div>
    <div class="nav-item">
      <a href="schedule.php" class="nav-link <?= ($activePage ?? '') === 'schedule' ? 'active' : '' ?>">
        <i class="bi bi-calendar-week-fill"></i><span>Schedule</span>
      </a>
    </div>

    <p class="nav-section-label mt-3">Account</p>

    <div class="nav-item">
      <a href="profile.php" class="nav-link <?= ($activePage ?? '') === 'profile' ? 'active' : '' ?>">
        <i class="bi bi-person-circle"></i><span>Profile</span>
      </a>
    </div>
  </nav>

  <div class="sidebar-footer">
    <div class="user-info">
      <div class="avatar-circle"><?= $avatarLetter ?></div>
      <div class="user-details">
        <div class="user-name"><?= $currentUser ?></div>
        <div class="user-email"><?= $currentEmail ?></div>
      </div>
    </div>
    <a href="api/logout.php" class="btn btn-logout mt-3 w-100">
      <i class="bi bi-box-arrow-right me-2"></i>Logout
    </a>
  </div>
</aside>

<!-- ===== MAIN CONTENT ===== -->
<div class="main-content" id="mainContent">
  <!-- Mobile header -->
  <div class="mobile-header d-flex d-md-none">
    <button class="btn btn-icon" id="sidebarToggle">
      <i class="bi bi-list fs-4"></i>
    </button>
    <span class="fw-700 text-primary">StudyPlanner</span>
  </div>
