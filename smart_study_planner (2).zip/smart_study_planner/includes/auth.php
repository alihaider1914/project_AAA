<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('ssp_session');
    session_start();
}

function requireLogin(): void
{
    if (empty($_SESSION['user_id'])) {
        $isApiRequest = str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');
        if ($isApiRequest) {
            http_response_code(401);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Unauthorized. Please log in.']);
        } else {
            header('Location: login.html');
        }
        exit;
    }
}

function currentUserId(): int
{
    return (int) ($_SESSION['user_id'] ?? 0);
}

function currentUserName(): string
{
    return $_SESSION['user_name'] ?? 'User';
}

function isLoggedIn(): bool
{
    return !empty($_SESSION['user_id']);
}
