<?php
function jsonResponse(bool $success, string $message = '', $data = null, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data]);
    exit;
}

function sanitize(string $input): string
{
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function validateEmail(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function getJsonInput(): array
{
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?? [];
}
